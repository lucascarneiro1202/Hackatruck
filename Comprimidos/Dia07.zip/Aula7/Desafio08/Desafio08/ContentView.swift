//
//  ContentView.swift
//  Desafio08
//
//  Created by Turma21-02 on 25/03/25.
//

import SwiftUI

import MapKit

struct Location: Hashable {
    let nome: String
    let foto: String
    let descricao: String
    let latitude: Double
    let longitude: Double
}

var locations: [Location] = [
    Location (
        nome: "Igreja da Pampulha",
        foto: "https://portalacustica.info/wp-content/uploads/2024/10/SITE-1-1.png",
        descricao: "A Igreja de São Francisco de Assis ( Igreja de São Francisco de Assis , comumente conhecida como Igreja da Pampulha ) é uma capela na região da Pampulha , em Belo Horizonte , no estado de Minas Gerais , sudeste do Brasil . Foi projetada pelo arquiteto brasileiro Oscar Niemeyer no estilo moderno orgânico . É o primeiro monumento arquitetônico moderno listado no Brasil e consiste em quatro parábolas onduladas de concreto com mosaicos externos. O interior abriga um mural de Candido Portinari , e o exterior apresenta uma paisagem projetada por Roberto Burle Marx . [ 1 ]",
        latitude: -19.85833333, longitude: -43.97888889
    ),
    Location (
        nome: "Palácio do Planalto",
        foto: "https://live.staticflickr.com/5479/14062639285_2e1dae27c3_h.jpg",
        descricao: "Palácio do Planalto é o local de trabalho da Presidência do Brasil.[1] É onde está situado o Gabinete do Presidente da República. O prédio também abriga a Casa Civil, a Secretaria-Geral e o Gabinete de Segurança Institucional da Presidência da República. Concebido pelo arquiteto Oscar Niemeyer com projeto estrutural do engenheiro Joaquim Cardozo, é a sede do Poder Executivo Federal do Brasil. Localizado na Praça dos Três Poderes em Brasília, o Palácio do Planalto faz parte do projeto do Plano Piloto e foi um dos primeiros edifícios construídos na capital.",
        latitude: -15.7931351608, longitude: -47.8585332325
    ),
    Location (
        nome: "Cristo Redentor",
        foto: "https://aosviajantes.com.br/wp-content/uploads/2016/08/novo-cristo-redentor-corcovado-paineiras.jpg",
        descricao: "Cristo Redentor é uma estátua que retrata Jesus Cristo localizada no topo do morro do Corcovado, a 709 metros acima do nível do mar, dentro do Parque Nacional da Tijuca. Tem vista para parte considerável da cidade brasileira do Rio de Janeiro, sendo a frente da estátua voltada para a Baía de Guanabara e as costas para a Floresta da Tijuca. Feito de concreto armado e pedra-sabão,[1][2][3] tem trinta metros de altura (uma das maiores estátuas do mundo), sem contar os oito metros do pedestal, sendo a mais alta estátua do mundo no estilo Art Déco.[4][5] Seus braços se esticam por 28 metros de largura e a estrutura pesa 1145 toneladas.[6]",
        latitude: -22.95194444, longitude: -43.21055556
    ),
    Location (
        nome: "Elevador Lacerda",
        foto: "https://tourb.com.br/img/lugares/salvador/elevador-lacerda.jpg",
        descricao: "O Elevador Lacerda é um sistema de transporte público da cidade de Salvador, capital do estado brasileiro da Bahia. Trata-se do primeiro elevador urbano do mundo. Em 8 de dezembro de 1873, quando a primeira torre foi inaugurada, era o elevador mais alto do mundo, com 63 metros. A estrutura atual, de 1930, tem 72 metros de altura.[1] Faz o transporte de pessoas entre a Praça Cairu, na Cidade Baixa, e a Praça Tomé de Sousa, na Cidade Alta. É um dos principais pontos turísticos e cartão-postal da cidade. Do alto de suas torres, descortina-se a vista para a Baía de Todos-os-Santos, o Mercado Modelo e, ao fundo, o Forte de São Marcelo.",
        latitude: -12.97416667, longitude: -38.51305556
    ),
    Location (
        nome: "Monte Roraima",
        foto: "https://turismodenatureza.com.br/wp-content/uploads/2019/03/O_que_fazer_no_Monte_Roraima.jpg",
        descricao: "O monte Roraima é um monte localizado na América do Sul, na tríplice fronteira entre Brasil, Venezuela e Guiana. Constitui um tepui, um tipo de monte em formato de mesa bastante característico do planalto das Guianas. Delimitado por falésias de cerca de 1 000 metros de altura, seu planalto apresenta um ambiente totalmente diferente da floresta tropical e da savana que se estende a seus pés. Assim, o alto índice pluviométrico promoveu a formação de pseudocarstes e de numerosas cavernas, além do processo de lixiviação do solo. A flora adaptou-se a essas condições climáticas e geológicas com um elevado grau de endemismo, onde encontram-se diversas espécies de plantas carnívoras – que retiram dos insetos capturados os nutrientes que faltam no solo. A fauna também é marcada por um acentuado endemismo, especialmente entre répteis e anfíbios. Esse ambiente é protegido no território venezuelano pelo Parque Nacional Canaima e no território brasileiro pelo Parque Nacional do Monte Roraima. Seu ponto culminante eleva-se no extremo sul, no estado venezuelano de Bolívar, a 2 810 metros de altitude. O segundo ponto mais alto, com 2 772 metros, localiza-se ao norte do planalto, em território guianense, próximo ao marco de fronteira entre os três países.",
        latitude: 5.203769207, longitude: -60.715301514
    ),
    Location (
        nome: "Lençóis Maranhenses",
        foto: "https://revista.bancorbras.com.br/wp-content/uploads/2023/12/Dunas-de-areias_Maranhao-scaled.jpg",
        descricao: "O Parque Nacional dos Lençóis Maranhenses é uma unidade de conservação brasileira de proteção integral à natureza localizada na região nordeste do estado do Maranhão. O território do parque, com uma área de 156 584 ha, está distribuído pelos municípios de Barreirinhas, Primeira Cruz e Santo Amaro do Maranhão.[1] O parque foi criado com a finalidade precípua de \"proteger a flora, a fauna e as belezas naturais, existentes no local.\"[2][5] Inserido no bioma costeiro marinho e cerrado, o parque é um exponente dos ecossistemas de mangue, restinga e dunas, associando ventos fortes e chuvas regulares. Sua grande beleza cênica, aliada aos passeios de ecoturismo pelos campos de dunas e à possibilidade de banhar-se nas lagoas e observação do céu noturno, atraem turistas de todo o mundo, que visitam o parque durante o ano inteiro.[6]",
        latitude: -2.53333333, longitude: -43.11666667
    )
]

struct ContentView: View {
    
    @State private var position = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: -14.2350, longitude: -51.9253),
            span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30)
        )
    )
    
    @State private var selectedLocation = locations[0]
    
    @State var auxiliarLocation = locations[0]
    
    @State private var showLocation = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                VStack {
                    Map(position: $position) {
                        ForEach(locations, id: \.self) { l in
                            Annotation(l.nome, coordinate: CLLocationCoordinate2D(latitude: l.latitude, longitude: l.longitude)) {
                                VStack {
                                    if selectedLocation.hashValue == l.hashValue {
                                        Button(action: {
                                            auxiliarLocation = l
                                            showLocation.toggle()
                                        }) {
                                            Image(systemName: "pin.fill")
                                                .resizable()
                                                .scaleEffect(1.5)
                                        }
                                    } else {
                                        Button(action: {
                                            auxiliarLocation = l
                                            showLocation.toggle()
                                        }) {
                                            Image(systemName: "pin")
                                                .resizable()
                                                .scaleEffect(1.0)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .ignoresSafeArea()
                }
                
                VStack {
                    VStack {
                        Picker("Escolha uma localização", selection: $selectedLocation) {
                            ForEach(locations, id: \.self) { l in
                                Text(l.nome)
                            }
                            .foregroundStyle(.black)
                        }
                        .tint(.black)
                        .onChange(of: selectedLocation, {
                            withAnimation{
                                position = MapCameraPosition.region(
                                    MKCoordinateRegion(
                                        center: CLLocationCoordinate2D(latitude: selectedLocation.latitude, longitude: selectedLocation.longitude),
                                        span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
                                    )
                                )
                            }
                        })
                    }
                    .padding()
                    .background(.yellow)
                    .cornerRadius(10.0)
                    
                    Spacer()
                    
                    HStack {
                        Text("Maravilhas do Brasil")
                    }
                    .padding()
                    .background(.yellow)
                    .cornerRadius(10.0)
                }
                .padding()
                
            }
        }
        .tint(.black)
        .sheet(isPresented: $showLocation, content: {
            LocationView(location: $auxiliarLocation)
        })
    }
}

#Preview {
    ContentView()
}
