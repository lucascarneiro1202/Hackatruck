//
//  LocationView.swift
//  Desafio08
//
//  Created by Turma21-02 on 25/03/25.
//

import SwiftUI

struct LocationView: View {
    
    @Binding var location : Location
    
    var body: some View {
        ZStack {
            Color(.yellow)
                .ignoresSafeArea()
            VStack {
                AsyncImage(url: URL(string: location.foto)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 250, height: 250)
                } placeholder: {
                    Image(systemName: "questionmark.app")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 250, height: 250)
                }
                Text(location.nome)
                    .font(.title)
                    .bold()
                ScrollView(.vertical) {
                    Text(location.descricao)
                        .padding(30)
                }
                .background(.brown)
            }
            .padding(30)
        }
    }
}
//
//#Preview {
//    LocationView( location:
//        Location (
//            nome: "Igreja da Pampulha",
//            foto: "https://portalacustica.info/wp-content/uploads/2024/10/SITE-1-1.png",
//            descricao: "A Igreja de São Francisco de Assis ( Igreja de São Francisco de Assis , comumente conhecida como Igreja da Pampulha ) é uma capela na região da Pampulha , em Belo Horizonte , no estado de Minas Gerais , sudeste do Brasil . Foi projetada pelo arquiteto brasileiro Oscar Niemeyer no estilo moderno orgânico . É o primeiro monumento arquitetônico moderno listado no Brasil e consiste em quatro parábolas onduladas de concreto com mosaicos externos. O interior abriga um mural de Candido Portinari , e o exterior apresenta uma paisagem projetada por Roberto Burle Marx . [ 1 ]",
//            latitude: -19.85833333, longitude: -43.97888889
//        )
//    )
//}
