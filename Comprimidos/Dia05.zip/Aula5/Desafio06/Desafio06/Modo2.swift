//
//  Modo2.swift
//  Desafio06
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct Modo2: View {
    
    @State var username = ""
    
    var body: some View {
        ZStack {
            Color.myDarkGray
            VStack(spacing: 10) {
                Text("**Modo 2**")
                    .font(.title)
                    .foregroundStyle(.white)
                Spacer()
                VStack {
                    TextField("Digite seu nome", text: $username)
                          .multilineTextAlignment(.center)
                    Text("**Bem-vindo, \(username)**")
                        .font(.title)
                    NavigationLink(destination: Modo2b(username: $username)) {
                        Text("Acessar Tela")
                    }
                    .padding(10)
                    .cornerRadius(5.0)
                    .background(.blue)
                    .foregroundStyle(.white)
                }
                .padding(20)
                .frame(width: 350, height: 200)
                .background(.pink)
                .foregroundColor(.white)
                .cornerRadius(10.0)
                .bold()
                Spacer()
            }
        }
        .padding()
        .background(.myDarkGray)
    }
}

#Preview {
    Modo2()
}
