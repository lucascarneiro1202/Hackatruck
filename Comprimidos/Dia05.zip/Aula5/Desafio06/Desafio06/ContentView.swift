//
//  ContentView.swift
//  Desafio06
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct ContentView: View {
    
    @State var presentSheet = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.myDarkGray
                VStack(spacing: 10) {
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(CGSize(width: 0.8, height: 0.8))
                    Spacer()
                    HStack {
                        NavigationLink(destination: Modo1()) {
                            Text("Modo 1")
                        }
                    }
                    .frame(width: 250, height: 100)
                    .background(.pink)
                    .foregroundColor(.white)
                    .cornerRadius(5.0)
                    HStack {
                        NavigationLink(destination: Modo2()) {
                            Text("Modo 2")
                        }
                    }
                    .frame(width: 250, height: 100)
                    .background(.pink)
                    .cornerRadius(5.0)
                    .foregroundColor(.white)
                    HStack {
                        Button("Modo 3") {
                            presentSheet.toggle()
                        }
                        .sheet(isPresented: $presentSheet) {
                            print("Sheet dismissed!")
                        } content: {
                            Modo3()
                        }
                    }
                    .frame(width: 250, height: 100)
                    .background(.pink)
                    .cornerRadius(5.0)
                    .foregroundColor(.white)
                    Spacer()
                    Spacer()
                }
            }
            .padding()
            .background(.myDarkGray)
        }
    }
}

#Preview {
    ContentView()
}
