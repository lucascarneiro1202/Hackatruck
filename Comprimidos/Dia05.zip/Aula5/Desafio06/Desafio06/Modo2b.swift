//
//  Modo2b.swift
//  Desafio06
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct Modo2b: View {
    
    @Binding var username: String
    
    var body: some View {
        ZStack {
            Color.myDarkGray
            VStack {
                Text("**Volte, \(username)!!**")
                    .font(.title)
            }
            .padding(20)
            .frame(width: 250, height: 100)
            .background(.pink)
            .foregroundColor(.white)
            .cornerRadius(5.0)
        }
        .padding()
        .background(.myDarkGray)
    }
}

//#Preview {
//    Modo2b($username)
//}
