//
//  Modo1.swift
//  Desafio06
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct Modo1: View {
    var body: some View {
        ZStack {
            Color.myDarkGray
            VStack(spacing: 10) {
                Text("**Modo 1**")
                    .font(.title)
                    .foregroundStyle(.white)
                Spacer()
                VStack {
                    Text("Nome: Lucas")
                    Text("Sobrenome: Carneiro")
                }
                .frame(width: 250, height: 100)
                .background(.pink)
                .foregroundColor(.white)
                .cornerRadius(5.0)
                Spacer()
            }
        }
        .padding()
        .background(.myDarkGray)
    }
}

#Preview {
    Modo1()
}
