//
//  Azul.swift
//  Desafio05
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct AzulView: View {
    var body: some View {
        ZStack {
            Color.blue
                .edgesIgnoringSafeArea(.top)
            Circle()
                .foregroundStyle(.black)
                .padding(40)
            Image(systemName: "paintbrush.pointed")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .foregroundStyle(.blue)
        }
    }
}

#Preview {
    AzulView()
}
