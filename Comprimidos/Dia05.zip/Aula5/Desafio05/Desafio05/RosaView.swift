//
//  RosaView.swift
//  Desafio05
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct RosaView: View {
    var body: some View {
        ZStack {
            Color.pink
                .edgesIgnoringSafeArea(.top)
            Circle()
                .foregroundStyle(.black)
                .padding(40)
            Image(systemName: "paintbrush")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .foregroundStyle(.pink)
        }
    }
}

#Preview {
    RosaView()
}
