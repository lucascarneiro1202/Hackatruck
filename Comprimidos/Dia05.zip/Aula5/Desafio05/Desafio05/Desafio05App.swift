//
//  Desafio05App.swift
//  Desafio05
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

@main
struct Desafio05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
