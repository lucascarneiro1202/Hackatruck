//
//  CinzaView.swift
//  Desafio05
//
//  Created by Turma21-02 on 21/03/25.
//

import SwiftUI

struct CinzaView: View {
    var body: some View {
        ZStack {
            Color.gray
                .edgesIgnoringSafeArea(.top)
            Circle()
                .foregroundStyle(.black)
                .padding(40)
            Image(systemName: "paintpalette")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .foregroundStyle(.gray)
        }
    }
}

#Preview {
    CinzaView()
}
