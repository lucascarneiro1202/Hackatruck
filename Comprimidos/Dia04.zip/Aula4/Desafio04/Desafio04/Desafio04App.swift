//
//  Desafio04App.swift
//  Desafio04
//
//  Created by Turma21-02 on 20/03/25.
//

import SwiftUI

@main
struct Desafio04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
