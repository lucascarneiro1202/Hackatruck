//
//  ContentView.swift
//  Desafio04
//
//  Created by Turma21-02 on 20/03/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var distancia = 0.00
    @State private var tempo = 0.00
    @State private var velocidade = 0.00
    
    @State private var velocidadeInvalida = false
    
    @State private var backgroundColor : Color = .gray
    @State private var imagemPrincipal = "Interrogacao"
    
    private let animais = ["TARTARUGA", "ELEFANTE", "AVESTRUZ", "LEÃO", "GUEPARDO"]
    private let velocidades = ["(0 - 9,9km/h)", "(10 - 29,9km/h)", "(30 - 69,9km/h)", "(70 - 89,9km/h)", "(90 - 130km/h)"]
    private let cores: [Color] = [.lightGreen, .lightBlue, .lightOrange, .lightYellow, .lightRed]
    private let imagens = ["Tartaruga", "Elefante", "Avestruz", "Leão", "Guepardo"]
    
    var body: some View {
        VStack (spacing: 20) {
            VStack (spacing: -5) {
                Text("Digite a distância (km):")
                TextField("", value: $distancia, format: .number)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.center)
                
                Text("Digite o tempo (h):")
                TextField("", value: $tempo, format: .number)
                    .keyboardType(.decimalPad)
                    .textContentType(.oneTimeCode)
                    .padding()
                    .textFieldStyle(.roundedBorder)
                    .multilineTextAlignment(.center)
                
                Button(action: {
                    calcularVelocidade()
                }) {
                    Text("Calcular")
                      .padding()
                      .foregroundColor(.red)
                      .background(.black)
                      .cornerRadius(10)
                }
                .alert(isPresented:$velocidadeInvalida) {
                    Alert(
                        title: Text("ALERTA !"),
                        message: Text("O tempo não pode ser zero!"),
                        dismissButton: .default(Text("Vamos corrigir!"))
                    )
                }
            }
            
            Spacer()
            
            VStack () {
                Text("\(velocidade, specifier: "%.2f") km/h")
                    .font(.largeTitle)
                Image(imagemPrincipal)
                    .resizable()
                    .scaledToFill()
                    .clipShape(Circle())
                    .frame(width: 200, height: 200)
            }
            
            Spacer()
            
            VStack(alignment: .center) {
                ForEach(0..<5) { i in
                    HStack {
                        Text(animais[i])
                        Spacer()
                        Text(velocidades[i])
                        Circle()
                            .foregroundColor(cores[i])
                            .frame(width: 20, height: 20)
                    }
                    .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
                }
            }
            .padding(EdgeInsets(top: 20, leading: 0, bottom: 20, trailing: 0))
            .background(.black)
            .cornerRadius(10.0)
            .foregroundColor(.white)
        }
        .padding(EdgeInsets(top: 0, leading: 50, bottom: 0, trailing: 50))
        .background(backgroundColor)
    }
    
    func calcularVelocidade() {
        if tempo <= 0 {
            velocidadeInvalida = true
        } else {
            velocidade = distancia / tempo
        }
        
        switch(velocidade) {
            case 0.1..<10:
                imagemPrincipal = "Tartaruga"
                backgroundColor = .lightGreen
                break
            case 10..<30:
                imagemPrincipal = "Elefante"
                backgroundColor = .lightBlue
                break
            case 30..<70:
                imagemPrincipal = "Avestruz"
                backgroundColor = .lightOrange
                break
            case 70..<90:
                imagemPrincipal = "Leão"
                backgroundColor = .lightYellow
                break
            case 90..<130.1:
                imagemPrincipal = "Guepardo"
                backgroundColor = .lightRed
                break
            default:
                imagemPrincipal = "Interrogacao"
                backgroundColor = .gray
                break
        }
    }
}

#Preview {
    ContentView()
}
