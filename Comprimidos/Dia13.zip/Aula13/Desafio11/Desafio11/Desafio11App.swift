//
//  Desafio11App.swift
//  Desafio11
//
//  Created by Turma21-02 on 01/04/25.
//

import SwiftUI

@main
struct Desafio11App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
