//
//  ViewModel.swift
//  Desafio11
//
//  Created by Turma21-02 on 01/04/25.
//

import Foundation

class ViewModel: ObservableObject {
    
    @Published var umidades : [Umidade] = []
    
    func fetch() {
        // guard led - Cria a variável e testa se ela é válida
        guard let url = URL(string: "http://192.168.128.13:1880/umidadeGet") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else { return }
            
            do {
                let parsed = try JSONDecoder().decode([Umidade].self, from: data)
                
                print(parsed)
                
                DispatchQueue.main.async {
                    self?.umidades = parsed
                }
            } catch {
                print(error)
            }
        }
        
        task.resume()
    }
    
}
