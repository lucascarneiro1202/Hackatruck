//
//  ContentView.swift
//  Desafio11
//
//  Created by Turma21-02 on 01/04/25.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [.white, .blue, .blue, .blue, .blue, .black]),
                startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
            ScrollView(.vertical) {
                Spacer()
                
                VStack(spacing: 10) {
                    Text("Umidade")
                        .font(.title)
                        .padding()
                        .background(.white)
                        .cornerRadius(10.0)
                    Spacer()
                    Text("As seguintes medições foram feitas a partir de uma construção com um microcontrolador, um potenciômetro e um sensor de umidade. Para fins de testes, o sensor de umidade foi imerso em uma esponja úmida.")
                        .padding()
                        .background(.white)
                        .cornerRadius(10.0)
                }
                .padding(EdgeInsets(top: 0, leading: 30, bottom: 0, trailing: 30))
                
                Spacer()
                
                VStack(alignment: .center) {
                    ForEach(viewModel.umidades, id: \.self) { umidade in
                        HStack {
                            Image(systemName: (
                                (umidade.umidade as NSString).doubleValue < 40.0 ? "drop" : "drop.fill")
                            )
                            .foregroundStyle(.blue)
                            Text("Umidade: \(String(format: "%05.2f", (umidade.umidade as NSString).doubleValue))")
                        }
                        .padding()
                        .background(.white)
                        .cornerRadius(10.0)
                    }
                }
                .padding(30)
                
                Spacer()
                
            }
        }
        .onAppear() {
            viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
