//
//  Model.swift
//  Desafio11
//
//  Created by Turma21-02 on 01/04/25.
//

import Foundation

struct Umidade : Codable, Hashable {
    var _id : String
    var _rev: String
    var umidade : String
}
