//
//  JogadorQuadraView.swift
//  Desafio10
//
//  Created by Turma21-02 on 27/03/25.
//

import SwiftUI

struct JogadorQuadraView: View {
    
    @State var jogador : Jogador
    
    var body: some View {
        NavigationStack {
            VStack {
                AsyncImage(url: URL(string: jogador.image)) { image in
                    image
                        .resizable()
                        .scaledToFit()
                        .cornerRadius(10.0)
//                        .clipShape(Circle())
                } placeholder: {
                    ProgressView()
                        .frame(width: 200, height: 200)
                        .scaleEffect(5.0)
                }
                Text(jogador.apelido)
                    .padding(10)
                    .background(.blue)
                    .foregroundStyle(.white)
                    .cornerRadius(10.0)
            }
        }
    }
}

//#Preview {
//    JogadorQuadraView()
//}
