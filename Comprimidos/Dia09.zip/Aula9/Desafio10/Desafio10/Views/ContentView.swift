//
//  ContentView.swift
//  Desafio10
//
//  Created by Turma21-02 on 27/03/25.
//

import SwiftUI

let backgroundImage = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Volleyball_Court.svg/1500px-Volleyball_Court.svg.png"

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    @State var posicao = "Ponteiro"
    
    var body: some View {
        NavigationStack {
            ZStack {
                AsyncImage(url: URL(string: backgroundImage)) { image in
                    image
                        .resizable()
                        .scaledToFit().ignoresSafeArea()
                        .scaleEffect(1.3)
                } placeholder: {
                    ProgressView()
                        .frame(width: 200, height: 200)
                        .scaleEffect(5.0)
                }
                
                VStack {
                    VStack {
                        Text("Sada Cruzeiro")
                            .font(.title)
                            .padding(30)
                            .background(.white)
                            .foregroundStyle(.blue)
                            .cornerRadius(10.0)
                    }
                    
                    Spacer()
                    
                    VStack {
                        HStack {
                            VStack {
                                ForEach(viewModel.jogadores, id: \.id) { j in
                                    if j.apelido == "Rodriguinho" {
                                        NavigationLink(destination: JogadorView(jogador: j)) {
                                            JogadorQuadraView(jogador: j)
                                        }
                                    }
                                }
                            }
                            
                            VStack {
                                ForEach(viewModel.jogadores, id: \.id) { j in
                                    if j.apelido == "Lucão" {
                                        NavigationLink(destination: JogadorView(jogador: j)) {
                                            JogadorQuadraView(jogador: j)
                                        }
                                    }
                                }
                            }
                            
                            VStack {
                                ForEach(viewModel.jogadores, id: \.id) { j in
                                    if j.apelido == "Oppenkoski" {
                                        NavigationLink(destination: JogadorView(jogador: j)) {
                                            JogadorQuadraView(jogador: j)
                                        }
                                    }
                                }
                            }
                        }
                        
                        HStack {
                            VStack {
                                ForEach(viewModel.jogadores, id: \.id) { j in
                                    if j.apelido == "Alê" {
                                        NavigationLink(destination: JogadorView(jogador: j)) {
                                            JogadorQuadraView(jogador: j)
                                        }
                                    }
                                }
                            }
                            
                            VStack {
                                ForEach(viewModel.jogadores, id: \.id) { j in
                                    if j.apelido == "Douglas Souza" {
                                        NavigationLink(destination: JogadorView(jogador: j)) {
                                            JogadorQuadraView(jogador: j)
                                        }
                                    }
                                }
                            }
                            
                            VStack {
                                ForEach(viewModel.jogadores, id: \.id) { j in
                                    if j.apelido == "Brasília" {
                                        NavigationLink(destination: JogadorView(jogador: j)) {
                                            JogadorQuadraView(jogador: j)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding()
                    
                    Spacer()
                }
            }
         }
        .onAppear() {
            viewModel.fetch()
        }
        .tint(.white)
    }
}

#Preview {
    ContentView()
}
