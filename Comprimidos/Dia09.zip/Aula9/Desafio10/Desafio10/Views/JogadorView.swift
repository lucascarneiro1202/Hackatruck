//
//  JogadorView.swift
//  Desafio10
//
//  Created by Turma21-02 on 27/03/25.
//

import SwiftUI

struct JogadorView: View {
    
    @State var jogador : Jogador
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [.blue, .white]),
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack {
                Spacer()
                
                AsyncImage(url: URL(string: jogador.image)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 200, height: 300)
                        .cornerRadius(10.0)
                } placeholder: {
                    ProgressView()
                        .frame(width: 200, height: 300)
                        .scaleEffect(5.0)
                }
                
                Spacer()
                
                VStack {
                    Text("Nome Completo: \(jogador.nome)")
                    Text("Apelido: \(jogador.nome)")
                    Text("Posição: \(jogador.nome)")
                    Text("Número da Camisa: \(jogador.numero)")
                    Text("Altura: \(jogador.altura)")
                    Text("Peso: \(jogador.peso)")
                    Text("Data de Nascimento: \(jogador.nome)")
                    Text("Jogou Olimpíadas? \(jogador.jogouOlimpiada ? "Sim" : "Não")")
                    Text("Naturalidade: \(jogador.naturalidade)")
                }
                .padding()
                .background(.white)
                .foregroundStyle(.blue)
                .cornerRadius(10.0)
                
                Spacer()
            }
        }
    }
}

//#Preview {
//    JogadorView()
//}
