//
//  ViewModel.swift
//  Desafio10
//
//  Created by Turma21-02 on 27/03/25.
//

import Foundation

class ViewModel: ObservableObject {
    
    @Published var jogadores : [Jogador] = []
    
    func fetch() {
        // guard led - Cria a variável e testa se ela é válida
        guard let url = URL(string: "http://192.168.128.10:1880/readAugusto") else { return }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else { return }
            
            do {
                let parsed = try JSONDecoder().decode([Jogador].self, from: data)
                
                print(parsed)
                
                DispatchQueue.main.async {
                    self?.jogadores = parsed
                }
            } catch {
                print(error)
            }
        }
        
        task.resume()
    }
    
}
