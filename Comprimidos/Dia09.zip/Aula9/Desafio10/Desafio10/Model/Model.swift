//
//  Model.swift
//  Desafio10
//
//  Created by Turma21-02 on 27/03/25.
//

import Foundation

struct Jogador : Codable, Identifiable {
    let _id : String
    let _rev : String
    let id : Int
    let nome : String
    let apelido : String
    let posicao : String
    let numero : Int
    let altura : Float
    let peso : Int
    let dataNascimento : String
    let titulosSada : [String]
    let jogouOlimpiada : Bool
    let naturalidade : String
    let image : String
}


/**
 */
