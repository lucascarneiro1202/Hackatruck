//
//  Desafio10App.swift
//  Desafio10
//
//  Created by Turma21-02 on 27/03/25.
//

import SwiftUI

@main
struct Desafio10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
