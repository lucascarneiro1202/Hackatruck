//
//  SongView.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import SwiftUI

struct SongView: View {
    
    @State var song : Song
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [.red, .black]),
                startPoint: .top, endPoint: .bottom)
            VStack {
                Spacer()
                Spacer()
                
                VStack {
                    AsyncImage(url: URL(string: song.capa)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 230, height: 230)
                    } placeholder: {
                        Image(systemName: "questionmark.app.fill")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 230, height: 230)
                    }
                    Text("\(song.nome)")
                        .font(.title2)
                    Text("\(song.artista)")
                        .font(.subheadline)
                }
                
                Spacer()
                
                HStack {
                    Image(systemName: "shuffle")
                        .resizable()
                        .frame(width: 30, height: 30)
                    Spacer()
                    Image(systemName: "backward.end.fill")
                        .resizable()
                        .frame(width: 35, height: 35)
                    Spacer()
                    Image(systemName: "play.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                    Spacer()
                    Image(systemName: "forward.end.fill")
                        .resizable()
                        .frame(width: 35, height: 35)
                    Spacer()
                    Image(systemName: "repeat")
                        .resizable()
                        .frame(width: 30, height: 30)
                }
                .padding()
                
                Spacer()
                Spacer()
            }
        }
        
        .edgesIgnoringSafeArea(.all)
        .foregroundStyle(.white)
    }
}

#Preview {
    SongView(
        song: Song(id: 1,
             nome: "Escorpião",
             artista: "Jão",
             capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb"
            )
    )
}
