//
//  Variables.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import Foundation



struct Song: Identifiable {
    var id: Int
    var nome: String
    var artista: String
    var capa: String
}

struct Playlist: Identifiable {
    var id: Int
    var nome: String
    var criador: String
    var capa: String
    let musicas: [Song]
}

var playlists: [Playlist] = [
       Playlist(
           id: 1,
           nome: "Jão",
           criador: "Lucas",
           capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb",
           musicas: [
               Song(id: 1,
                    nome: "Escorpião",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb"
                   ),
               Song(id: 2,
                    nome: "Me Lambe",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb"
                   ),
               Song(id: 3,
                    nome: "Maria",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb"
                   ),
               Song(id: 4,
                    nome: "Eu Posso Ser Como Você",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb"
                   ),
               Song(id: 5,
                    nome: "Alinhamento Milenar",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d00001e0260d1becd51ababd7fc01c2fb"
                   ),
               Song(id: 6,
                    nome: "Idiota",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d0000b27376086200d394250d6eef8adf"
                   ),
               Song(id: 7,
                    nome: "Santo",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d0000b27376086200d394250d6eef8adf"
                   ),
               Song(id: 8,
                    nome: "Acontece",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d0000b27376086200d394250d6eef8adf"
                   ),
               Song(id: 9,
                    nome: "Coringa",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d0000b27376086200d394250d6eef8adf"
                   ),
               Song(id: 10,
                    nome: "Doce",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d0000b27376086200d394250d6eef8adf"
                   ),
           ]
       ),
       Playlist(
           id: 2,
           nome: "Lagum",
           criador: "Lucas",
           capa: "https://i.scdn.co/image/ab67616d00001e024cedf031ee76c7fbd3f969ef",
           musicas: [
               Song(id: 1,
                    nome: "Oi",
                    artista: "Lagum",
                    capa: "https://i.scdn.co/image/ab67616d00001e024cedf031ee76c7fbd3f969ef"
                   ),
               Song(id: 2,
                    nome: "É seu",
                    artista: "Lagum",
                    capa: "https://i.scdn.co/image/ab67616d00001e024cedf031ee76c7fbd3f969ef"
                   ),
               Song(id: 3,
                    nome: "Depois do Fim",
                    artista: "Lagum",
                    capa: "https://i.scdn.co/image/ab67616d00001e0268757c8aaaaf5d2c9d7838d1"
                   ),
               Song(id: 4,
                    nome: "Outro Alguém",
                    artista: "Lagum",
                    capa: "https://i.scdn.co/image/ab67616d00001e0268757c8aaaaf5d2c9d7838d1"
                   ),
               Song(id: 5,
                    nome: "Habite-se",
                    artista: "Lagum",
                    capa: "https://i.scdn.co/image/ab67616d00001e0268757c8aaaaf5d2c9d7838d1"
                   ),
               Song(id: 6,
                    nome: "NINGUÉM ME ENSINOU",
                    artista: "Jão",
                    capa: "https://i.scdn.co/image/ab67616d00001e0222f71e5db9bff577622a9f61"
                   ),
           ]
       )
   ]
