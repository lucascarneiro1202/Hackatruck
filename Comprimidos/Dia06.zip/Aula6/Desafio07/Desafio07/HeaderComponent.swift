//
//  HeaderComponent.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import SwiftUI

struct HeaderComponent: View {
    
    @Binding var idPlaylist : Int
    
    var body: some View {
        HStack {
            AsyncImage(url: URL(string: playlists[idPlaylist - 1].capa)) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } placeholder: {
                Image(systemName: "questionmark.app.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            .frame(width: 200, height: 200)
        }
        
        VStack(alignment: .leading) {
            Text("\(playlists[idPlaylist - 1].nome)")
                .font(.largeTitle)
            HStack {
                AsyncImage(url: URL(string: playlists[idPlaylist - 1].capa)) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                } placeholder: {
                    Image(systemName: "questionmark.app.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }
                .frame(width: 25, height: 25)
                Text("\(playlists[idPlaylist - 1].criador)")
                    .font(.callout)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: 90, alignment: .leading)
        .padding()
    }
}

//#Preview {
//    HeaderComponent()
//}
