//
//  SongsComponent.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import SwiftUI

struct SongsComponent: View {
    
    @Binding var idPlaylist : Int
    
    var body: some View {
        VStack {
            ForEach(playlists[idPlaylist - 1].musicas, id: \.id) { s in
                HStack{
                    NavigationLink(destination: SongView(song: s)) {
                        AsyncImage(url: URL(string: s.capa)) { image in
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 70, height: 70)
                        } placeholder: {
                            Image(systemName: "questionmark.app.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 70, height: 70)
                        }
                        VStack(alignment: .leading) {
                            Text("\(s.nome)")
                                .font(.callout)
                            Text("\(s.artista)")
                                .font(.caption)
                                .foregroundStyle(.gray)
                        }
                        Spacer()
                        Image(systemName: "ellipsis")
                    }
                    .navigationBarBackButtonHidden(true)
                }
                .frame(maxWidth: .infinity, maxHeight: 90, alignment: .center)
                .padding()
            }
        }
    }
}

//#Preview {
//    SongsComponent()
//}
