//
//  PlaylistView.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import SwiftUI

struct PlaylistView: View {
    
    
    @State var idPlaylist = 1
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [.red, .black]),
                    startPoint: .top, endPoint: .bottom)
                ScrollView(.vertical) {
                    HeaderComponent(idPlaylist: $idPlaylist)
                    
                    SongsComponent(idPlaylist: $idPlaylist)
                    
                    SuggestedComponent(idPlaylist: $idPlaylist)
                }
                .foregroundStyle(.white)
                .padding(EdgeInsets(top: 110.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
            }
            .edgesIgnoringSafeArea(.all)
        }
        .tint(.white)
    }
}

#Preview {
    PlaylistView()
}
