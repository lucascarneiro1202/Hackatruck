//
//  SuggestedComponent.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import SwiftUI

struct SuggestedComponent: View {
    
    @Binding var idPlaylist : Int
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Sugeridos")
                .font(.largeTitle)
            ScrollView(.horizontal) {
                ForEach(playlists, id: \.id) { p in
                    if (p.id != (idPlaylist)) {
                        NavigationLink(destination: PlaylistView(idPlaylist: p.id)) {
                            VStack(spacing: 10) {
                                AsyncImage(url: URL(string: p.capa)) { image in
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 150, height: 150)
                                } placeholder: {
                                    Image(systemName: "questionmark.app")
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 150, height: 150)
                                }
                                Text("\(p.nome)")
                        }
                        
//                        Button(action: {
//                            idPlaylist = p.id
//                            print(idPlaylist)
//                        }) {
//                            VStack(spacing: 10) {
//                                AsyncImage(url: URL(string: p.capa)) { image in
//                                    image
//                                        .resizable()
//                                        .aspectRatio(contentMode: .fit)
//                                        .frame(width: 150, height: 150)
//                                } placeholder: {
//                                    Image(systemName: "questionmark.app")
//                                        .resizable()
//                                        .aspectRatio(contentMode: .fit)
//                                        .frame(width: 150, height: 150)
//                                }
//                                Text("\(p.nome)")
//                            }
                        }
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: 100, alignment: .leading)
        .padding(EdgeInsets(top: 100.0, leading: 10.0, bottom: 120.0, trailing: 10.0))
    }
}

//#Preview {
//    SuggestedComponent()
//}
