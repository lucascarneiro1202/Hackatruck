//
//  Desafio07App.swift
//  Desafio07
//
//  Created by Turma21-02 on 24/03/25.
//

import SwiftUI

@main
struct Desafio07App: App {
    var body: some Scene {
        WindowGroup {
            PlaylistView()
        }
    }
}
