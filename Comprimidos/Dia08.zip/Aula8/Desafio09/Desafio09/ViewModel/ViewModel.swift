//
//  ViewModel.swift
//  Desafio09
//
//  Created by Turma21-02 on 26/03/25.
//

import Foundation

class ViewModel: ObservableObject {
    
    @Published var personagens : [HarryPotter] = []
    
    func fetch() {
        // guard led - Cria a variável e testa se ela é válida
        guard let url = URL(string: "https://hp-api.onrender.com/api/characters/house/gryffindor") else { return }
        
        // Cria uma requisição que tem os parâmetros: dados, response e erro
            // dados - '[weak self] data' cria uma referência fraca para evitar vazamento de memória
            // response - '_' deixa o parâmetro anônimo
            // error - 'error' é uma variável que armazena a mensagem de erro
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            // Confirma a validade dos dados e testa se não houve erro
            guard let data = data, error == nil else { return }
            
            // Inicia um bloco try-catch
            do {
                // Tenta decodificar 'data' para um JSON no formato da classe HarryPotter e armazena na variável 'parsed'
                let parsed = try JSONDecoder().decode([HarryPotter].self, from: data)
                
                print(parsed)
                
                // Cria uma tarefa assíncrona na thread principal para atualizar a variável 'personagens'
                DispatchQueue.main.async {
                    self?.personagens = parsed
                }
            } catch {
                print(error)
            }
        }
        
        // Iniciar de fato a busca
        task.resume()
    }
    
}
