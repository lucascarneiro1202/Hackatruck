//
//  PersonagemView.swift
//  Desafio09
//
//  Created by Turma21-02 on 26/03/25.
//

import SwiftUI

struct PersonagemView: View {
    
    @State var personagem : HarryPotter
    
    var body: some View {
        ZStack {
            Color.darkRed
                .ignoresSafeArea()
            VStack {
                
                Spacer()
                
                if personagem.image != nil {
                    AsyncImage(url: URL(string: personagem.image!)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 200, height: 200)
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    } placeholder: {
                        ProgressView()
                            .frame(width: 200, height: 200)
                            .scaleEffect(5.0)
                    }
                }
                
                Spacer()
                
                VStack(alignment: .leading, spacing: 3) {
                    if personagem.name != nil {
                        Text("Nome: \(personagem.name!)")
                    }
                    
                    if personagem.species != nil {
                        Text("Espécie: \(personagem.species!.capitalized)")
                    }
                    
                    if personagem.gender != nil {
                        Text("Gênero: \(personagem.gender! == "male" ? "Homem" : "Mulher")")
                    }
                    
                    if personagem.house != nil {
                        Text("Casa: \(personagem.house!)")
                    }
                    
                    if personagem.dateOfBirth != nil {
                        Text("Data de Nascimento: \(personagem.dateOfBirth!)")
                    }
                    
                    if personagem.yearOfBirth != nil {
                        Text("Ano de Nascimento: \(personagem.yearOfBirth!)")
                    }
                    
                    if personagem.wizard != nil {
                        Text("É um bruxo? \(personagem.wizard! ? "Sim" : "Não")")
                    }
                    
                    if personagem.ancestry != nil {
                        Text("Ancestralidade: \(personagem.ancestry!.capitalized)")
                    }
                    
                    if personagem.eyeColor != nil {
                        Text("Cor do Olho: \(personagem.eyeColor!.capitalized)")
                    }
                    
                    if personagem.hairColor != nil {
                        Text("Cor do Cabelo: \(personagem.hairColor!.capitalized)")
                    }
                    
                    if personagem.wand.wood != nil {
                        Text("Madeira da Varinha: \(personagem.wand.wood!.capitalized)")
                    }
                    
                    if personagem.wand.core != nil {
                        Text("Núcleo da Varinha: \(personagem.wand.core!.capitalized)")
                    }
                    
                    if personagem.wand.length != nil {
                        Text("Comprimento da Varinha: \(personagem.wand.length!)")
                    }
                    
                    if personagem.patronus != nil {
                        Text("Patrono: \(personagem.patronus!.capitalized)")
                    }
                    
                    if personagem.hogwartsStudent != nil {
                        Text("É estudante de Hogwarts? \(personagem.hogwartsStudent! ? "Sim" : "Não")")
                    }
                    
                    if personagem.hogwartsStaff != nil {
                        Text("É funcionário de Hogwarts? \(personagem.hogwartsStaff! ? "Sim" : "Não")")
                    }
                    
                    if personagem.actor != nil {
                        Text("Nome do ator: \(personagem.actor!)")
                    }
                    
                    if personagem.alive != nil {
                        Text("Está vivo? \(personagem.alive! ? "Sim" : "Não")")
                    }
                }
                .padding()
                .background(.mediumYellow)
                .cornerRadius(10.0)
                
                Spacer()
            }
        }
    }
}

/*
 
 let name : String?
 let alternate_names : [String]?
 let species : String?
 let gender : String?
 let house : String?
 let dateOfBirth : String?
 let yearOfBirth: Int?
 let wizard: Bool?
 let ancestry: String?
 let eyeColor: String?
 let hairColor: String?
 let wand : Wand
 let patronus : String?
 let hogwartsStudent : Bool?
 let hogwartsStaff : Bool?
 let actor : String?
 let alternate_actors : [String]
 let alive : Bool?
 let image : String?
 
 */
