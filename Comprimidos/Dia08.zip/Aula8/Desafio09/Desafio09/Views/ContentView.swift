//
//  ContentView.swift
//  Desafio09
//
//  Created by Turma21-02 on 26/03/25.
//

import SwiftUI

//let backgroundGrifinoria = "https://recreio.com.br/media/_versions/harry_potter/quadribol_grifinoria_capa_widelg.png"

let backgroundGrifinoria = "https://guiaviajarmelhor.com.br/wp-content/uploads/2020/02/livraria-lello-harry-potter.jpg"

let logoGrifinonia = "https://static.wikia.nocookie.net/harrypotter/images/1/15/Gryffindor_crest_by_readingnerd0415_de0kjre-pre.png/revision/latest?cb=20220722063443&path-prefix=pt-br"

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.darkRed
                    .ignoresSafeArea()
                ScrollView(.vertical) {
                    ZStack {
                        AsyncImage(url: URL(string: backgroundGrifinoria)) { image in
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(maxWidth: .infinity, maxHeight: 250)
                                .opacity(0.2)
                                .scaleEffect(1.3)
                                .ignoresSafeArea()
                        } placeholder: {}
                        
                        AsyncImage(url: URL(string: logoGrifinonia)) { image in
                            image
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 200, height: 200)
                                .padding(70)
                        } placeholder: {}
                    }
                    VStack {
                        ForEach(viewModel.personagens, id: \.id) { p in
                            
                            HStack(spacing: 2) {
                                if p.image != nil && p.name != nil {
                                    NavigationLink(destination: PersonagemView(personagem: p)) {
                                        AsyncImage(url: URL(string: p.image!)) { image in
                                            image
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(width: 60, height: 60)
                                                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                        } placeholder: {
                                            ProgressView()
                                                .frame(width: 60, height: 60)
                                                .scaleEffect(2.5)
                                        }
                                        
                                        Text(p.name!)
                                            .font(.title3)
                                            .foregroundStyle(.white)
                                            .padding()
                                        
                                        Spacer()
                                    }
                                }
                            }
                            .padding()
                        }
                    }
                }
                .edgesIgnoringSafeArea(.top)
            }
        }
        .tint(.white)
        .onAppear() {
            viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
