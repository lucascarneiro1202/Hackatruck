//
//  Desafio09App.swift
//  Desafio09
//
//  Created by Turma21-02 on 26/03/25.
//

import SwiftUI

@main
struct Desafio09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
