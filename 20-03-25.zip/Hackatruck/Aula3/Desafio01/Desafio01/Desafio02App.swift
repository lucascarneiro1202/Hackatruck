//
//  Desafio02App.swift
//  Desafio01
//
//  Created by Turma21-02 on 19/03/25.
//

import SwiftUI

struct Desafio02App: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Desafio02App()
}
