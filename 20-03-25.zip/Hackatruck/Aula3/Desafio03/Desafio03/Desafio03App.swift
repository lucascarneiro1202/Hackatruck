//
//  Desafio03App.swift
//  Desafio03
//
//  Created by Turma21-02 on 19/03/25.
//

import SwiftUI

@main
struct Desafio03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
