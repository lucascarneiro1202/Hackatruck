//
//  Desafio02App.swift
//  Desafio02
//
//  Created by Turma21-02 on 19/03/25.
//

import SwiftUI

@main
struct Desafio02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
